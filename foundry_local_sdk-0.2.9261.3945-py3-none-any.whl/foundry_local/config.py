# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
# --------------------------------------------------------------------------
from __future__ import annotations

import sys

from pydantic import BaseModel, Field

if sys.version_info >= (3, 11):
    from enum import StrEnum

else:
    from enum import Enum

    class StrEnum(str, Enum):
        def __str__(self) -> str:
            return self.value


# ruff: noqa: N815


class DeviceType(StrEnum):
    """Device supported by model"""

    CPU = "CPU"
    GPU = "GPU"
    NPU = "NPU"


class ExecutionProvider(StrEnum):
    CPU = "CPUExecutionProvider"
    WEBGPU = "WebGpuExecutionProvider"
    CUDA = "CUDAExecutionProvider"
    QNN = "QNNExecutionProvider"

    def get_alias(self) -> str:
        """Get the alias for the execution provider."""
        return self.value.replace("ExecutionProvider", "").lower()


class ModelRuntime(BaseModel):
    """Model runtime information"""

    deviceType: DeviceType = Field(..., description="Device type supported by the model")
    executionProvider: ExecutionProvider = Field(
        ...,
        description="Execution provider supported by the model",
    )


class FoundryListResponseModel(BaseModel):
    """Response model for listing models"""

    name: str = Field(..., description="Name of the model")
    displayName: str = Field(..., description="Display name of the model")
    modelType: str = Field(..., description="Type of the model")
    providerType: str = Field(..., description="Provider type of the model")
    uri: str = Field(..., description="URI of the model")
    version: str = Field(..., description="Version of the model")
    promptTemplate: dict = Field(..., description="Prompt template for the model")
    publisher: str = Field(..., description="Publisher of the model")
    task: str = Field(..., description="Task of the model")
    runtime: ModelRuntime = Field(..., description="Runtime information of the model")
    fileSizeMb: int = Field(..., description="File size of the model in MB")
    modelSettings: dict = Field(..., description="Model settings")
    alias: str = Field(..., description="Alias name of the model")
    supportsToolCalling: bool = Field(..., description="Whether the model supports tool calling")
    license: str = Field(..., description="License of the model")
    licenseDescription: str = Field(..., description="License description of the model")
    parentModelUri: str = Field(..., description="Parent model URI of the model")


class FoundryModelInfo(BaseModel):
    """Model information"""

    alias: str = Field(..., description="Alias of the model")
    id: str = Field(..., description="Unique identifier of the model")
    version: str = Field(..., description="Version of the model")
    runtime: ExecutionProvider = Field(..., description="Execution provider of the model")
    uri: str = Field(..., description="URI of the model")
    model_size: int = Field(..., description="Size of the model on disk in MB")
    prompt_template: dict = Field(..., description="Prompt template for the model")
    provider: str = Field(..., description="Provider of the model")
    publisher: str = Field(..., description="Publisher of the model")

    def __repr__(self) -> str:
        return (
            f"FoundryModelInfo(alias={self.alias}, id={self.id}, runtime={self.runtime.get_alias()},"
            f" model_size={self.model_size} MB)"
        )

    @classmethod
    def from_list_response(cls, response: dict | FoundryListResponseModel) -> FoundryModelInfo:
        """Create a FoundryModelInfo object from a FoundryListResponseModel object."""
        if isinstance(response, dict):
            response = FoundryListResponseModel.model_validate(response)
        return cls(
            alias=response.alias,
            id=response.name,
            version=response.version,
            runtime=response.runtime.executionProvider,
            uri=response.uri,
            model_size=response.fileSizeMb,
            prompt_template=response.promptTemplate,
            provider=response.providerType,
            publisher=response.publisher,
        )

    def to_download_body(self) -> dict:
        """Convert the FoundryModelInfo object to a dictionary for download."""
        return {
            "Name": self.id,
            "Uri": self.uri,
            "Publisher": self.publisher,
            "ProviderType": f"{self.provider}Local" if self.provider == "AzureFoundry" else self.provider,
            "PromptTemplate": self.prompt_template,
        }
